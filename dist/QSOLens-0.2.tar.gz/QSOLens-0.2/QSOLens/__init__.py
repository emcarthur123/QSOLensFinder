from .NetworkArchitecture import predict

__all__ = ['predict']